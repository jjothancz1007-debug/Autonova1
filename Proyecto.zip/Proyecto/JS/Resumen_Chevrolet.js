document.addEventListener('DOMContentLoaded', () => {
  const resumenLista = document.getElementById('resumenLista');
  const totalSpan = document.getElementById('total');
  const btnBorrarTodo = document.getElementById('borrarTodo');

  let resumen = JSON.parse(localStorage.getItem('resumenChevrolet')) || [];

  function actualizarLista() {
    resumenLista.innerHTML = '';
    let total = 0;

    resumen.forEach((ref, index) => {
      const li = document.createElement('li');

      const divIzq = document.createElement('div');
      divIzq.style.display = 'flex';
      divIzq.style.alignItems = 'center';

      const img = document.createElement('img');
      img.src = ref.imagen;
      img.alt = ref.nombre;
      img.style.width = "50px";
      img.style.height = "50px";
      img.style.marginRight = "10px";

      const nombre = document.createElement('span');
      nombre.textContent = ref.nombre;

      divIzq.appendChild(img);
      divIzq.appendChild(nombre);

      const divDer = document.createElement('div');
      const precio = document.createElement('span');
      precio.textContent = `$${ref.precio}`;

      const btnQuitar = document.createElement('button');
      btnQuitar.textContent = '❌';
      btnQuitar.style.marginLeft = '10px';
      btnQuitar.style.cursor = 'pointer';
      btnQuitar.style.background = 'transparent';
      btnQuitar.style.border = 'none';
      btnQuitar.style.color = '#ff4500';
      btnQuitar.style.fontSize = '18px';

      btnQuitar.addEventListener('click', () => {
        resumen.splice(index, 1);
        localStorage.setItem('resumenChevrolet', JSON.stringify(resumen));
        actualizarLista();
      });

      divDer.appendChild(precio);
      divDer.appendChild(btnQuitar);

      li.appendChild(divIzq);
      li.appendChild(divDer);

      resumenLista.appendChild(li);

      total += ref.precio;
    });

    totalSpan.textContent = total;
  }

  actualizarLista();

  // --- Modal ---
  const modal = document.getElementById('clienteModal');
  const btnConfirmar = document.getElementById('confirmarPedido');
  const btnCerrar = document.getElementById('cerrarModal');
  const btnGuardar = document.getElementById('guardarCliente');

  btnConfirmar.addEventListener('click', () => {
    modal.style.display = "block";
  });

  btnCerrar.addEventListener('click', () => {
    modal.style.display = "none";
  });

  btnGuardar.addEventListener('click', () => {
    const cliente = {
      nombre: document.getElementById('clienteNombre').value || "N/D",
      direccion: document.getElementById('clienteDireccion').value || "N/D",
      rfc: document.getElementById('clienteRFC').value || "N/D",
      email: document.getElementById('clienteEmail').value || "N/D",
      telefono: document.getElementById('clienteTelefono').value || "N/D"
    };

    const pedidoCompleto = { resumen, cliente };
    localStorage.setItem('pedidoChevrolet', JSON.stringify(pedidoCompleto));

    window.location.href = "ConfirmacionChevrolet.html";
  });

  // Borrar todo
  btnBorrarTodo.addEventListener('click', () => {
    resumen = [];
    localStorage.removeItem('resumenChevrolet');
    actualizarLista();
  });

  // --- Sidebar y navegación ---
  document.getElementById('logout').addEventListener('click', () => {
    alert("Has cerrado sesión");
    window.location.href = "Inicio.html";
  });
  document.getElementById('menuPrincipal').addEventListener('click', () => {
    window.location.href = "Menu1.html";
  });
  document.getElementById('nosotros').addEventListener('click', () => {
    window.location.href = "Nosotros.html";
  });
  document.getElementById('contactanos').addEventListener('click', () => {
    window.location.href = "Contacto.html";
  });
  document.getElementById('toggleSidebar').addEventListener('click', () => {
    document.querySelector('.sidebar').classList.toggle('active');
  });
});