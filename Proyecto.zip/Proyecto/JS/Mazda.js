document.addEventListener('DOMContentLoaded', () => {
  const refaccionesContainer = document.getElementById('refaccionesContainer');

  const refaccionesMazda = [
    {nombre: "Bujías", precio: 520, imagen: "IMG/bujias.png"},
    {nombre: "Aceite motor", precio: 740, imagen: "IMG/aceite.png"},
    {nombre: "Filtro de aire", precio: 310, imagen: "IMG/filtro_aire.png"},
    {nombre: "Pastillas freno", precio: 1250, imagen: "IMG/pastillas_freno.png"},
    {nombre: "Amortiguadores", precio: 2550, imagen: "IMG/amortiguador.png"},
    {nombre: "Correa de distribución", precio: 1850, imagen: "IMG/correa.png"},
    {nombre: "Batería", precio: 2250, imagen: "IMG/bateria.png"},
    {nombre: "Radiador", precio: 3450, imagen: "IMG/radiador.png"},
    {nombre: "Filtro de aceite", precio: 420, imagen: "IMG/filtro_aceite.png"},
    {nombre: "Balatas traseras", precio: 1150, imagen: "IMG/balatas.png"}
  ];

  refaccionesMazda.forEach(ref => {
    const div = document.createElement('div');
    div.classList.add('refaccion');

    const img = document.createElement('img');
    img.src = ref.imagen;
    img.alt = ref.nombre;

    const nombre = document.createElement('span');
    nombre.textContent = ref.nombre;

    const precio = document.createElement('span');
    precio.textContent = `$${ref.precio}`;

    div.appendChild(img);
    div.appendChild(nombre);
    div.appendChild(precio);

    div.addEventListener('click', () => {
      let resumen = JSON.parse(localStorage.getItem('resumenMazda')) || [];
      resumen.push(ref);
      localStorage.setItem('resumenMazda', JSON.stringify(resumen));
      mostrarNotificacion(`${ref.nombre} agregado al resumen`);
    });

    refaccionesContainer.appendChild(div);
  });

  const btnResumen = document.createElement('button');
  btnResumen.textContent = "Ver Resumen";
  btnResumen.classList.add('resumen-btn');
  btnResumen.addEventListener('click', () => {
    window.location.href = 'Resumen_Mazda.html';
  });
  document.querySelector('.main-content').appendChild(btnResumen);

  function mostrarNotificacion(mensaje) {
    const notificacion = document.createElement('div');
    notificacion.classList.add('notificacion');
    notificacion.textContent = mensaje;

    document.body.appendChild(notificacion);

    setTimeout(() => {
      notificacion.remove();
    }, 2000);
  }

  const toggleSidebar = document.getElementById('toggleSidebar');
  const sidebar = document.querySelector('.sidebar');

  toggleSidebar.addEventListener('click', () => {
    sidebar.classList.toggle('active');
  });

  document.getElementById('logout').addEventListener('click', () => {
    alert("Has cerrado sesión");
    window.location.href = "Inicio.html";
  });

  document.getElementById('menuPrincipal').addEventListener('click', () => {
    window.location.href = "Menu1.html";
  });

  document.getElementById('nosotros').addEventListener('click', () => {
    window.location.href = "nosotros.html";
  });

  document.getElementById('contactanos').addEventListener('click', () => {
    window.location.href = "contacto.html";
  });
});