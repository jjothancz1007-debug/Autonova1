document.addEventListener('DOMContentLoaded', () => {
  const refaccionesContainer = document.getElementById('refaccionesContainer');
  const mensajeEmergente = document.getElementById('mensajeEmergente');

  const refaccionesToyota = [
    {nombre: "Bujías", precio: 500, imagen: "IMG/bujias.png"},
    {nombre: "Aceite motor", precio: 700, imagen: "IMG/aceite.png"},
    {nombre: "Filtro de aire", precio: 300, imagen: "IMG/filtro_aire.png"},
    {nombre: "Pastillas freno", precio: 1200, imagen: "IMG/pastillas_freno.png"},
    {nombre: "Amortiguadores", precio: 2500, imagen: "IMG/amortiguador.png"},
    {nombre: "Correa de distribución", precio: 1800, imagen: "IMG/correa.png"},
    {nombre: "Batería", precio: 2200, imagen: "IMG/bateria.png"},
    {nombre: "Radiador", precio: 3500, imagen: "IMG/radiador.png"},
    {nombre: "Balatas traseras", precio: 950, imagen: "IMG/balatas.png"},
    {nombre: "Filtro de aceite", precio: 250, imagen: "IMG/filtro_aceite.png"}
  ];

  refaccionesToyota.forEach(ref => {
    const div = document.createElement('div');
    div.classList.add('refaccion');

    const img = document.createElement('img');
    img.src = ref.imagen;
    img.alt = ref.nombre;

    const nombre = document.createElement('span');
    nombre.textContent = ref.nombre;

    const precio = document.createElement('span');
    precio.textContent = `$${ref.precio}`;

    const btn = document.createElement('button');
    btn.textContent = "Agregar";
    btn.classList.add('btn-agregar');

    btn.addEventListener('click', () => {
      let resumen = JSON.parse(localStorage.getItem('resumenToyota')) || [];
      resumen.push(ref);
      localStorage.setItem('resumenToyota', JSON.stringify(resumen));

      mostrarMensaje(`${ref.nombre} agregado al resumen`);
    });

    div.appendChild(img);
    div.appendChild(nombre);
    div.appendChild(precio);
    div.appendChild(btn);

    refaccionesContainer.appendChild(div);
  });

  function mostrarMensaje(texto) {
    mensajeEmergente.textContent = texto;
    mensajeEmergente.style.display = 'flex';
    setTimeout(() => {
      mensajeEmergente.style.display = 'none';
    }, 2000);
  }

  document.getElementById('btnResumen').addEventListener('click', () => {
    window.location.href = 'Resumen_Toyota.html';
  });

  const toggleSidebar = document.getElementById('toggleSidebar');
  const sidebar = document.querySelector('.sidebar');

  toggleSidebar.addEventListener('click', () => {
    sidebar.classList.toggle('active');
  });

  document.getElementById('logout').addEventListener('click', () => {
    alert("Has cerrado sesión");
    window.location.href = "Inicio.html";
  });

  document.getElementById('menuPrincipal').addEventListener('click', () => {
    window.location.href = "Menu1.html";
  });

  document.getElementById('nosotros').addEventListener('click', () => {
    window.location.href = "nosotros.html";
  });

  document.getElementById('contactanos').addEventListener('click', () => {
    window.location.href = "contacto.html";
  });
});