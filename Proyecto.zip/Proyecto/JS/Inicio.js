const loginForm = document.getElementById('loginForm');
const togglePwd = document.getElementById('togglePwd');
const passwordInput = document.getElementById('password');
const crearCuenta = document.getElementById('crearCuenta');
const createAccountForm = document.getElementById('createAccountForm');
const volverLogin = document.getElementById('volverLogin');

togglePwd.addEventListener('click', () => {
    passwordInput.type = passwordInput.type === 'password' ? 'text' : 'password';
});

loginForm.addEventListener('submit', e => {
    e.preventDefault();
    const email = document.getElementById('email').value;
    const username = document.getElementById('username').value;
    const password = passwordInput.value;

    
    if(email === "demo@autonova.com" && username === "demo" && password === "123456") {
        window.location.href = "Menu1.html"; 
    } else {
        alert("Correo, usuario o contraseña incorrectos");
    }
});

crearCuenta.addEventListener('click', e => {
    e.preventDefault();
    document.querySelector('.login-container').style.display = 'none';
    createAccountForm.style.display = 'block';
});

volverLogin.addEventListener('click', () => {
    createAccountForm.style.display = 'none';
    document.querySelector('.login-container').style.display = 'block';
});