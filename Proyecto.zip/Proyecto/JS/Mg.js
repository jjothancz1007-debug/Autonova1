document.addEventListener('DOMContentLoaded', () => {
  const refaccionesContainer = document.getElementById('refaccionesContainer');

  const refaccionesMG = [
    {nombre: "Bujías", precio: 480, imagen: "IMG/bujias.png"},
    {nombre: "Aceite motor", precio: 720, imagen: "IMG/aceite.png"},
    {nombre: "Filtro de aire", precio: 290, imagen: "IMG/filtro_aire.png"},
    {nombre: "Pastillas freno", precio: 1100, imagen: "IMG/pastillas_freno.png"},
    {nombre: "Amortiguadores", precio: 2400, imagen: "IMG/amortiguador.png"},
    {nombre: "Correa de distribución", precio: 1750, imagen: "IMG/correa.png"},
    {nombre: "Batería", precio: 2100, imagen: "IMG/bateria.png"},
    {nombre: "Radiador", precio: 3300, imagen: "IMG/radiador.png"},
    {nombre: "Filtro de aceite", precio: 390, imagen: "IMG/filtro_aceite.png"},
    {nombre: "Balatas traseras", precio: 1090, imagen: "IMG/balatas.png"}
  ];

  refaccionesMG.forEach(ref => {
    const div = document.createElement('div');
    div.classList.add('refaccion');

    const img = document.createElement('img');
    img.src = ref.imagen;
    img.alt = ref.nombre;

    const nombre = document.createElement('span');
    nombre.textContent = ref.nombre;

    const precio = document.createElement('span');
    precio.textContent = `$${ref.precio}`;

    div.appendChild(img);
    div.appendChild(nombre);
    div.appendChild(precio);

    div.addEventListener('click', () => {
      let resumen = JSON.parse(localStorage.getItem('resumenMG')) || [];
      resumen.push(ref);
      localStorage.setItem('resumenMG', JSON.stringify(resumen));
      mostrarNotificacion(`${ref.nombre} agregado al resumen`);
    });

    refaccionesContainer.appendChild(div);
  });

  const btnResumen = document.createElement('button');
  btnResumen.textContent = "Ver Resumen";
  btnResumen.classList.add('resumen-btn');
  btnResumen.addEventListener('click', () => {
    window.location.href = 'Resumen_MG.html';
  });
  document.querySelector('.main-content').appendChild(btnResumen);

  function mostrarNotificacion(mensaje) {
    const notificacion = document.createElement('div');
    notificacion.classList.add('notificacion');
    notificacion.textContent = mensaje;

    document.body.appendChild(notificacion);

    setTimeout(() => {
      notificacion.remove();
    }, 2000);
  }

  const toggleSidebar = document.getElementById('toggleSidebar');
  const sidebar = document.querySelector('.sidebar');

  toggleSidebar.addEventListener('click', () => {
    sidebar.classList.toggle('active');
  });

  document.getElementById('logout').addEventListener('click', () => {
    alert("Has cerrado sesión");
    window.location.href = "Inicio.html";
  });

  document.getElementById('menuPrincipal').addEventListener('click', () => {
    window.location.href = "Menu1.html";
  });

  document.getElementById('nosotros').addEventListener('click', () => {
    window.location.href = "nosotros.html";
  });

  document.getElementById('contactanos').addEventListener('click', () => {
    window.location.href = "contacto.html";
  });
});