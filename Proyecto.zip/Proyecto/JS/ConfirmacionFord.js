document.addEventListener("DOMContentLoaded", () => {
  const fechaElemento = document.getElementById("fecha");
  const folioElemento = document.getElementById("folio");
  const tablaRefacciones = document.getElementById("tablaRefacciones");
  const subtotalElem = document.getElementById("subtotal");
  const ivaElem = document.getElementById("iva");
  const totalElem = document.getElementById("total");
  const btnImprimir = document.getElementById("btnImprimir");

  const ahora = new Date();
  const opciones = { year: "numeric", month: "long", day: "numeric", hour: "2-digit", minute: "2-digit" };
  fechaElemento.textContent = "Fecha de emisión: " + ahora.toLocaleDateString("es-ES", opciones);

  const aleatorio = Math.floor(1000 + Math.random() * 9000);
  const folio = `FAC-FORD-${ahora.getFullYear()}-${(ahora.getMonth()+1).toString().padStart(2,"0")}-${ahora.getDate().toString().padStart(2,"0")}-${aleatorio}`;
  folioElemento.textContent = folio;

  const pedido = JSON.parse(localStorage.getItem("pedidoFord")) || { resumen: [], cliente: {} };

  document.getElementById("cNombre").textContent = pedido.cliente.nombre || "N/D";
  document.getElementById("cDireccion").textContent = pedido.cliente.direccion || "N/D";
  document.getElementById("cRfc").textContent = pedido.cliente.rfc || "N/D";
  document.getElementById("cEmail").textContent = pedido.cliente.email || "N/D";
  document.getElementById("cTelefono").textContent = pedido.cliente.telefono || "N/D";
  
  let subtotal = 0;
  tablaRefacciones.innerHTML = "";
  function codigoInventado() {
    return "COD-" + Math.floor(1000 + Math.random() * 9000);
  }

  (pedido.resumen || []).forEach((item, i) => {
    const nombre = item.nombre || `Item ${i+1}`;
    const cantidad = item.cantidad || 1;
    const precio = Number(item.precio) || 0;
    const codigo = item.codigo && item.codigo !== "N/D" ? item.codigo : codigoInventado();
    const totalItem = cantidad * precio;
    subtotal += totalItem;

    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td><img src="${item.imagen || 'IMG/placeholder.png'}" class="img-ref"></td>
      <td>${nombre}</td>
      <td>${codigo}</td>
      <td>${cantidad}</td>
      <td>$${precio.toFixed(2)}</td>
      <td>$${totalItem.toFixed(2)}</td>
    `;
    tablaRefacciones.appendChild(tr);
  });

  const iva = subtotal * 0.16;
  const total = subtotal + iva;
  subtotalElem.textContent = "Subtotal: $" + subtotal.toFixed(2);
  ivaElem.textContent = "IVA (16%): $" + iva.toFixed(2);
  totalElem.innerHTML = "<strong>Total: $" + total.toFixed(2) + "</strong>";

  btnImprimir.addEventListener("click", () => {
    window.print();
  });

  document.getElementById('logout').addEventListener('click', () => {
    alert("Has cerrado sesión");
    window.location.href = "Inicio.html";
  });
  document.getElementById('menuPrincipal').addEventListener('click', () => {
    window.location.href = "Menu1.html";
  });
  document.getElementById('nosotros').addEventListener('click', () => {
    window.location.href = "Nosotros.html";
  });
  document.getElementById('contactanos').addEventListener('click', () => {
    window.location.href = "Contacto.html";
  });
  document.getElementById('toggleSidebar').addEventListener('click', () => {
    document.querySelector('.sidebar').classList.toggle('active');
  });
});