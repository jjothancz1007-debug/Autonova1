document.addEventListener('DOMContentLoaded', () => {
  const menuMarcas = document.getElementById('menuMarcas');
  const imagenCoche = document.getElementById('imagenCoche');
  const infoCoche = document.getElementById('infoCoche');
  const ficha = document.getElementById('ficha');
  const logoutBtn = document.getElementById('logout');
  const nosotrosBtn = document.getElementById('nosotros');
  const contactanosBtn = document.getElementById('contactanos');

  const data = [
    { marca: "Toyota", logo: "IMG/toyota.png", modelos: [
      {nombre:"Corolla", años:[
        {anio:"2020", imagen:"IMG/corolla2020.png"},
        {anio:"2021", imagen:"IMG/corolla2021.png"},
        {anio:"2022", imagen:"IMG/corolla2022.png"}
      ]},
      {nombre:"Camry", años:[
        {anio:"2019", imagen:"IMG/camar2019.png"},
        {anio:"2020", imagen:"IMG/camar2020.png"},
        {anio:"2021", imagen:"IMG/camar2021.png"}
      ]}
    ]},
    { marca: "Ford", logo: "IMG/ford.png", modelos: [
      {nombre:"Mustang", años:[
        {anio:"2018", imagen:"IMG/mustang2018.png"},
        {anio:"2019", imagen:"IMG/mustang2019.png"},
        {anio:"2020", imagen:"IMG/mustang2020.png"}
      ]},
      {nombre:"F-150", años:[
        {anio:"2021", imagen:"IMG/f1502021.png"},
        {anio:"2022", imagen:"IMG/f1502022.png"}
      ]}
    ]},
    { marca: "BMW", logo: "IMG/bmw.png", modelos: [
      {nombre:"X5", años:[
        {anio:"2019", imagen:"IMG/x52019.png"},
        {anio:"2020", imagen:"IMG/x52020.png"},
        {anio:"2021", imagen:"IMG/x52021.png"}
      ]},
      {nombre:"3 Series", años:[
        {anio:"2020", imagen:"IMG/3series2020.png"},
        {anio:"2021", imagen:"IMG/3series2021.png"}
      ]}
    ]},
    { marca: "Honda", logo: "IMG/honda.png", modelos: [
      {nombre:"Civic", años:[
        {anio:"2019", imagen:"IMG/civic2019.png"},
        {anio:"2020", imagen:"IMG/civic2020.png"},
        {anio:"2021", imagen:"IMG/civic2021.png"}
      ]},
      {nombre:"CR-V", años:[
        {anio:"2020", imagen:"IMG/crv2020.png"},
        {anio:"2021", imagen:"IMG/crv2021.png"},
        {anio:"2022", imagen:"IMG/crv2022.png"}
      ]}
    ]},
    { marca: "Mercedes", logo: "IMG/mercedes.png", modelos: [
      {nombre:"C-Class", años:[
        {anio:"2019", imagen:"IMG/cclass2019.png"},
        {anio:"2020", imagen:"IMG/cclass2020.png"},
        {anio:"2021", imagen:"IMG/cclass2021.png"}
      ]},
      {nombre:"GLE", años:[
        {anio:"2020", imagen:"IMG/gle2020.png"},
        {anio:"2021", imagen:"IMG/gle2021.png"},
        {anio:"2022", imagen:"IMG/gle2022.png"}
      ]}
    ]},
    { marca: "Cadillac", logo: "IMG/cadillac.png", modelos: [
      {nombre:"Escalade", años:[
        {anio:"2020", imagen:"IMG/escalade2020.png"},
        {anio:"2021", imagen:"IMG/escalade2021.png"}
      ]},
      {nombre:"XT5", años:[
        {anio:"2020", imagen:"IMG/xt52020.png"},
        {anio:"2021", imagen:"IMG/xt52021.png"}
      ]}
    ]},
    { marca: "Hyundai", logo: "IMG/hyundai.png", modelos: [
      {nombre:"Elantra", años:[
        {anio:"2020", imagen:"IMG/elantra2020.png"},
        {anio:"2021", imagen:"IMG/elantra2021.png"}
      ]},
      {nombre:"Tucson", años:[
        {anio:"2020", imagen:"IMG/tucson2020.png"},
        {anio:"2021", imagen:"IMG/tucson2021.png"}
      ]}
    ]},
    { marca: "Mazda", logo: "IMG/mazda.png", modelos: [
      {nombre:"CX-5", años:[
        {anio:"2020", imagen:"IMG/cx52020.png"},
        {anio:"2021", imagen:"IMG/cx52021.png"}
      ]},
      {nombre:"Mazda 3", años:[
        {anio:"2020", imagen:"IMG/mazda32020.png"},
        {anio:"2021", imagen:"IMG/mazda32021.png"}
      ]}
    ]},
    { marca: "MG", logo: "IMG/mg.png", modelos: [
      {nombre:"ZS", años:[
        {anio:"2020", imagen:"IMG/zs2020.png"},
        {anio:"2021", imagen:"IMG/zs2021.png"}
      ]},
      {nombre:"HS", años:[
        {anio:"2020", imagen:"IMG/hs2020.png"},
        {anio:"2021", imagen:"IMG/hs2021.png"}
      ]}
    ]},
    { marca: "Chevrolet", logo: "IMG/chevrolet.png", modelos: [
      {nombre:"Silverado", años:[
        {anio:"2020", imagen:"IMG/silverado2020.png"},
        {anio:"2021", imagen:"IMG/silverado2021.png"}
      ]},
      {nombre:"Camaro", años:[
        {anio:"2020", imagen:"IMG/camaro2020.png"},
        {anio:"2021", imagen:"IMG/camaro2021.png"}
      ]}
    ]}
  ];

  
  data.forEach(marcaObj => {
    const divMarca = document.createElement('div');
    divMarca.classList.add('marca');

    const imgLogo = document.createElement('img');
    imgLogo.src = marcaObj.logo;
    imgLogo.alt = marcaObj.marca;

    const nombreMarca = document.createElement('span');
    nombreMarca.textContent = marcaObj.marca;

    divMarca.appendChild(imgLogo);
    divMarca.appendChild(nombreMarca);

    const subMenu = document.createElement('div');
    subMenu.classList.add('submenu');

    divMarca.addEventListener('click', () => {
      subMenu.innerHTML = ''; 

      marcaObj.modelos.forEach(modelo => {
        const modeloDiv = document.createElement('div');
        modeloDiv.textContent = modelo.nombre;
        modeloDiv.style.cursor = 'pointer';
        modeloDiv.style.fontWeight = 'bold';
        modeloDiv.style.marginTop = '8px';

        modeloDiv.addEventListener('click', (e) => {
          e.stopPropagation();
          subMenu.innerHTML = ''; 

          modelo.años.forEach(añoObj => {
            const btnAnio = document.createElement('button');
            btnAnio.textContent = añoObj.anio;
            btnAnio.classList.add('btn-anio');

            btnAnio.addEventListener('click', (e) => {
              e.stopPropagation();
              imagenCoche.src = añoObj.imagen;
              infoCoche.textContent = `${marcaObj.marca} - ${modelo.nombre} - ${añoObj.anio}`;

              const prevBtn = document.querySelector('.btn-refacciones');
              if (prevBtn) prevBtn.remove();

              const btnRef = document.createElement('button');
              btnRef.classList.add('btn-refacciones');
              btnRef.textContent = `Ver Refacciones ${marcaObj.marca}`;
              btnRef.addEventListener('click', () => {
                window.location.href = `${marcaObj.marca.toLowerCase()}_refacciones.html`;
              });
              ficha.appendChild(btnRef);

              
              subMenu.innerHTML = '';
            });

            subMenu.appendChild(btnAnio);
          });
        });

        subMenu.appendChild(modeloDiv);
      });

      divMarca.appendChild(subMenu);
    });

    menuMarcas.appendChild(divMarca);
  });

  // 🔹 Botones barra lateral
  logoutBtn.addEventListener('click', () => {
    alert("Has cerrado sesión");
    window.location.href = "Inicio.html";
  });

  nosotrosBtn.addEventListener('click', () => {
    window.location.href = "nosotros.html";
  });

  contactanosBtn.addEventListener('click', () => {
    window.location.href = "contacto.html";
  });
});


const toggleSidebar = document.getElementById('toggleSidebar');
const sidebar = document.querySelector('.sidebar');

toggleSidebar.addEventListener('click', () => {
  sidebar.classList.toggle('active');
});