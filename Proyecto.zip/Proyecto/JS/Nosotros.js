document.addEventListener('DOMContentLoaded', () => {
  const btnMenu = document.getElementById('btnMenu');
  const btnContact = document.getElementById('btnContact');
  const logoutBtn = document.getElementById('logout');

  btnMenu.addEventListener('click', () => {
    window.location.href = 'Menu1.html';
  });

  btnContact.addEventListener('click', () => {
    window.location.href = 'contacto.html';
  });

  logoutBtn.addEventListener('click', () => {
    alert("Has cerrado sesión");
    window.location.href = "Inicio.html";
  });

  // 🔹 Toggle barra lateral
  const toggleSidebar = document.getElementById('toggleSidebar');
  const sidebar = document.querySelector('.sidebar');

  toggleSidebar.addEventListener('click', () => {
    sidebar.classList.toggle('active');
  });
});