document.addEventListener('DOMContentLoaded', () => {
  const menuCochesBtn = document.getElementById('menuCoches');
  const nosotrosBtn = document.getElementById('nosotros');
  const logoutBtn = document.getElementById('logout');

  menuCochesBtn.addEventListener('click', () => {
    window.location.href = 'Menu1.html';
  });

  nosotrosBtn.addEventListener('click', () => {
    window.location.href = 'nosotros.html';
  });

  logoutBtn.addEventListener('click', () => {
    alert("Has cerrado sesión");
    window.location.href = 'Inicio.html';
  });

  const toggleSidebar = document.getElementById('toggleSidebar');
  const sidebar = document.querySelector('.sidebar');

  toggleSidebar.addEventListener('click', () => {
    sidebar.classList.toggle('active');
  });
});